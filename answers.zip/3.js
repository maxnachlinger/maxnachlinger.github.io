/*
 3. Write a function that returns M random non-negative integers less
 than some value N.  Each integer must also be unique.
 */

function getNRandomIntsLessThan (amount, lessThan) {
  const ret = []
  const getInt = () => Math.floor(Math.random() * lessThan)

  for (let i = 0; i < amount; i++) {
    let n = getInt()
    while (ret.includes(n)) {
      n = getInt()
    }
    ret[i] = n
  }

  return ret
}
