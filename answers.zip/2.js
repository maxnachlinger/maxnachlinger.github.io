/*
 2. Write a quick and dirty program (not just a standalone function) to
 print a count of all the different "words" in a text file.  Use any
 definition of word that makes logical sense or makes your job easy.
 The output might look like this:
 */
const fs = require('fs')
const path = require('path')

// excess whitespace non-alpha chars
const whitespaceRegex = /\s{2,}/g
const cleanRegex = /\W/g

function readFileContents (fileName, callback) {
  return fs.readFile(fileName, 'utf8', (err, contents) => {
    if (err) {
      return callback(err)
    }

    return callback(null, contents.replace(cleanRegex, ' ').replace(whitespaceRegex, ' ').trim())
  })
}

function getWordMetrics (input) {
  return input.split(' ').reduce((stats, word) => {
    if (stats[ word ] === undefined) {
      stats[ word ] = 0
    }
    stats[ word ]++
    return stats
  }, {})
}

function sortWordMetrcs (metrics) {
  return Object.keys(metrics)
    .sort((w0, w1) => {
      if (metrics[ w0 ] > metrics[ w1 ]) {
        return -1
      }
      if (metrics[ w0 ] < metrics[ w1 ]) {
        return 1
      }
      return 0
    })
    .map((word) => {
      return {
        word,
        amt: metrics[ word ]
      }
    })
}

readFileContents(path.resolve(__dirname, '2.txt'), (err, contents) => {
  if (err) {
    console.error(err.stack)
    process.exit(1)
  }

  // break into an array of words
  const metrics = getWordMetrics(contents)
  const sortedMetrics = sortWordMetrcs(metrics)

  sortedMetrics.forEach((metric) => {
    console.log(metric.word, metric.amt)
  })
})

