/*
 4. Given a one dimensional array of data write a function that returns
 M random elements of that array.  Each element must also be from a
 different position in the array.
 */

function getRandomSample (inputArray, sampleSize) {
  const indexesUsed = []
  const length = inputArray.length
  const getIndex = () => Math.floor(Math.random() * (length - 1))
  const ret = []

  for (let i = 0; i < sampleSize; i++) {
    let index = getIndex()
    while (indexesUsed.includes(index)) {
      index = getIndex()
    }
    ret[ i ] = inputArray[index]
  }

  return ret
}

var arr =  Array.from({length: 100}, (i, idx) => idx)
console.log(getRandomSample(arr, 10))

