/*
 1. Given a one dimensional array of data write a function that returns
 a new array with the data reversed.  Don't just use the reverse
 function that is built into your environment.
 */

function reverse (arr) {
  return arr.reduce((accum, item) => {
    accum.unshift(item)
    return accum
  }, [])
}

var arr =  Array.from({length: 100}, (i, idx) => idx)
console.log(arr, reverse(arr))
